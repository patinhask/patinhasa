const help = (pushname, prefix, botName, ownerName, reqXp, uangku) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ Criador: ${botName}
║➩ ❍ wa.me/5511934660977
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


❍ 𝙻𝙸𝙼𝙸𝚃𝙴 

  ║➩ ❍ ${prefix}limite (ver seu limite)
  ║➩ ❍ ${prefix}buylimite (comprar limite)
  ║➩ ❍ ${prefix}bal (ver seu dinheiro)
  ║➩ Aumente seu level interagindo no grupo!!

  ║➩ ❍ ${prefix}
❍ 𝚂𝙾𝙱𝚁𝙴
  
  ║➩ ❍ ${prefix}blocklist *lista de numeros bloqueados
  ║➩ ❍ ${prefix}chatlist
  ║➩ ❍ ${prefix}ping
❍ 𝙵𝙰𝚉𝙴𝚁
  
  ║➩ ❍ ${prefix}figu
  ║➩ ❍ ${prefix}toimg (Transformar fig em foto)
  ║➩ ❍ ${prefix}virarmp3 (Transformar video em aúdio)
  ║➩ ❍ ${prefix}calunia
❍ 𝙼𝙴𝙳𝙸𝙰
  
  ║➩ ❍ ${prefix}randomkpop

❍ 𝙵𝙰𝙻𝙰𝙻𝙰𝚁 𝙲𝙾𝙼 𝙱𝙾𝚃 
  ║➩ ❍ ${prefix}avalie a probabilidade *pergunta

❍ 𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳

  ║➩ ❍ ${prefix}musica
  ║➩ ❍ ${prefix}audio pt 

❍ 𝙰𝙽𝙸𝙼𝙴𝚂
  
  ║➩ ❍ ${prefix}loli
  ║➩ ❍ ${prefix}waifu
  ║➩ ❍ ${prefix}randomanime
  ║➩ ❍ ${prefix}buscanime
  ║➩ ❍ ${prefix}nekonime

❍ 𝙾𝚄𝚃𝚁𝙾𝚂
 
  ║➩ ❍ ${prefix}wame
  ║➩ ❍ ${prefix}qrcode
  ║➩ ❍ ${prefix}afk
  ║➩ ❍ ${prefix}fml
  ║➩ ❍ ${prefix}fml2
  ❍𝙼𝙴𝙽𝚄 𝙰𝙳𝙼𝙸𝙽
  
 ║➩ ❍ ${prefix}abrirgp
 ║➩ ❍ ${prefix}fechargp
 ║➩ ❍ ${prefix}setname (Mudar nome do gp)
 ║➩ ❍ ${prefix}setdesc (Mudar a descrição)
 ║➩ ❍ ${prefix}promover (Tornar membro comum em adm)
 ║➩ ❍ ${prefix}rebaixar(Tornar adm em membro comum)
 ║➩ ❍ ${prefix}marcar
 ║➩ ❍ ${prefix}marcar2
 ║➩ ❍ ${prefix}marcar3
 ║➩ ❍ ${prefix}add ex: add 55....
 ║➩ ❍ ${prefix}remover @tag membro
 ║➩ ❍ ${prefix}listadmins
 ║➩ ❍ ${prefix}linkgp
 ║➩ ❍ ${prefix}sairgp (Bot sair do gp)
 ║➩ ❍ ${prefix}bv 
 ║➩ ❍ ${prefix}nsfw
 ║➩ ❍ ${prefix}leveling (Ativar o level no gp)
 ║➩ ❍ ${prefix}level
 ║➩ ❍ ${prefix}apagar (Apagar msg q o bot mandou)

❍ 𝙼𝙴𝙽𝚄 𝙽𝚂𝙵𝚆
 
  ║➩ ❍ ${prefix}randomhentai

❍ 𝙳𝙾𝙽𝙾
  
  ║➩ ❍ ${prefix}setprefix
  ║➩ ❍ ${prefix}block
  ║➩ ❍ ${prefix}exe
  ║➩ ❍ ${prefix}tm
  ║➩ ❍ ${prefix}tmctt
  ║➩ ❍ ${prefix}clone
  ║➩ ❍ ${prefix}clearall
`
}
exports.help = help
